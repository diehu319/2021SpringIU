package edu.indiana.cs.c343;

public class HammingDNADistance {

    public int hammingDist(String dna1, String dna2) {
        assert dna1.length() == dna2.length():"strings are of different length";
        int d = 0;
        for (int i = 0; i < dna1.length(); i ++) {
            if (dna1.charAt(i) != dna2.charAt(i)) d += 1;
        }
        return d;
    }
    

    
    // start of a test client:
    public static void main(String[] argv) {
        HammingDNADistance dist = new HammingDNADistance();
        RandomChunkOfDNA rnd = new RandomChunkOfDNA();
        String dna1 = rnd.nextDNA(100);
        String dna2 = rnd.nextDNA(100);
        System.out.println("dna1 = " + dna1);
        System.out.println("dna2 = " + dna2);
        int d = dist.hammingDist(dna1, dna2);
        System.out.println("Hamming distance = " + d);

        // (a complete ps01 solution should provide at least 3 examples)

    }

} // end of class HammingDNADistance
