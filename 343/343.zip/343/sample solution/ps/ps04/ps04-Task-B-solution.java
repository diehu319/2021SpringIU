// #### Problem Set 04 Task B ####


// ------
// Task B
// ------

// ...
    public boolean find(E q) {
        if (q.compareTo(value) == 0)
            return true;
        if (left != null) 
            if (left.find(q))
                return true;
        if (right != null) 
            if (right.find(q))
                return true;
        return false;
    }

    public static void main(String[] argv) {

// ...
        
        // now test the same node with a different type, e.g. String:
        BinNodeJr<String> rootW = new BinNodeJr<String>("fruit");
        BinNodeJr<String> node1W = new BinNodeJr<String>("pear");
        BinNodeJr<String> node2W = new BinNodeJr<String>("orange");
// ...etc...
        rootW.setLeft(node1W);
        rootW.setRight(node2W);
// ...etc...
        System.out.println("pear is found in the tree: " + rootW.find("pear"));
        System.out.println("lemon is found in the tree: " + rootW.find("lemon"));
// ...etc...
    }

// ...
