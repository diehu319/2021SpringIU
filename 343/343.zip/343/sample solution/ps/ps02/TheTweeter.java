// #### Problem Set 02 Task B start of a possible solution ####

import java.util.ArrayList;

public class TheTweeter {
    ArrayList<TweetClass> tweets;

    public static void main(String[] args) {
        TweetClass t1 = new TweetClass("a", "a message");
        TweetClass t2 = new TweetClass("a", "a message 2");
        TweetClass t3 = new TweetClass("b", "b message");
        TweetClass t4 = new TweetClass("c", "c message");
        TweetClass t5 = new TweetClass("d", "d message");
        TweetClass t6 = new TweetClass("e", "e message");

        TheTweeter tweeter = new TheTweeter();
        tweeter.add(t1);
        tweeter.add(t2);
        tweeter.add(t3);
        tweeter.add(t4);
        tweeter.add(t5);

        ArrayList<TweetClass> tweets = tweeter.tweets;

        for (TweetClass tweet : tweets) {
            System.out.println(tweet.getTweet());
        }

        System.out.println("============================");

        System.out.println("Added tweet by e: ");
        tweeter.add(t6);
        for (TweetClass tweet : tweets) {
            System.out.println(tweet.getTweet());
        }

        System.out.println("============================");

        System.out.println("Removed author b: ");
        tweeter.remove("b");
        for (TweetClass tweet : tweets) {
            System.out.println(tweet.getTweet());
        }

        System.out.println("============================");

        System.out.println("Getting tweet by a: ");
        System.out.println(tweeter.get("a").getTweet());

        System.out.println("============================");

        System.out.println("Removed author a: ");
        tweeter.remove("a");

        for (TweetClass tweet : tweets) {
            System.out.println(tweet.getTweet());
        }

        System.out.println("============================");

        System.out.println("Attempting to get tweet by nonexistent author x: ");
        System.out.println(tweeter.get("x"));
    }

    public TheTweeter() {
        this.tweets = new ArrayList<>();
    }

    public void add(TweetClass t) {
        tweets.add(t);
    }

    public void remove(String author) {
        for (int i = 0; i < tweets.size(); i++) {
            if (tweets.get(i).author.equals(author)) {
                tweets.remove(i--);
            }
        }
    }

    public TweetClass get(String author) {
        for (int i = 0; i < tweets.size(); i++) {
            if (tweets.get(i).author.equals(author)) {
                return tweets.get(i);
            }
        }

        return null;
    }
}