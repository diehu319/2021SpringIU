// #### Problem Set 02 Task C start of a possible solution ####

package edu.indiana.cs.c343;


public class Int2DArray implements Int2DArrayADT {
	private int[][] mat;
	private int rows;
	private int cols;
	
	/** 0. we could have a constructor.... */
	public Int2DArray(int nrow, int ncol) {
		rows = nrow;
		cols = ncol;
		mat = new int[rows][cols];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				mat[i][j] = 0;
			}
		}
	}

	/** 1. .... or a "create" method. */
	public void create(int nrow, int ncol) {
		rows = nrow;
		cols = ncol;
		mat = new int[rows][cols];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				mat[i][j] = 0;
			}
		}
	}

    /** 2. Return the number of rows */
	public int numRow() {
		return rows;
	}
    /** 3. Return the number of columns */
	public int numCol() {
		return cols;
	}

    /** 4. Set the value to the cell specified by a row index and a column index */
	public void set(int rowidx, int colidx, int val) {
		mat[rowidx][colidx] = val;
	}

    /** 5. Get the value in a cell */
	public int get(int rowidx, int colidx) {
		return mat[rowidx][colidx];
	}

    /** 10. Clear (set to 0) all the elements of the array */
	public void clear() {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				mat[i][j] = 0;
			}
		}
	}
	public static void main(String args[]) {
		Int2DArray m = new Int2DArray(4, 3);
		System.out.println(m.numRow());
		System.out.println(m.numCol());
		m.set(1, 2, 22);
		System.out.println(m.get(1, 2));
		m.clear();
		System.out.println(m.get(1, 2));
	}
}
