// #### Lab 01 Task C start of a possible solution ####



import static java.lang.Math.min;
import static java.lang.Math.random;
import static java.lang.System.out;

public class CalculateRunTimes {

    public void countInstructions(int n) {

        // very simple counter for logging running times:
        int instructioncounter;


        //
        // Example 1:
        //
        int sum1;
        int i;
        sum1 = 0;
        instructioncounter = 0;

        for (i = 1, instructioncounter++; i <= n; i++, instructioncounter++) {
            sum1++;
            instructioncounter++;
        }
        out.println("in Example 1, for size n = " + n + ", instructioncounter is: " + instructioncounter);

        //
        // Example 7:
        //

        // set up input & output for algorithm:
        int[] a = new int[n + 1];
        int[] b = new int[n + 1];
        int[][] d = new int[n + 1][n + 1];
        for (i = 0; i < a.length; i++) {
            a[i] = (int) (random() * 10);/**/
        }
        for (i = 0; i < b.length; i++) {
            b[i] = (int) (random() * 10);
        }
        int c;
        int j;

        // start counting:
        instructioncounter = 0;

        d[0][0] = 0;
        instructioncounter++;

        for (i = 1, instructioncounter++; i <= n; i++, instructioncounter++) {

            for (j = 1, instructioncounter++; j <= n; j++, instructioncounter++) {

                if (a[i] == b[j]) {
                    instructioncounter++;
                    c = 0;
                } else {
                    instructioncounter++;
                    c = 1;
                }

                d[i][j] = min(
                        d[i - 1][j] + 1,
                        min(
                                d[i][j - 1] + 1,
                                d[i - 1][j - 1] + c
                        )
                );
                instructioncounter++; // for the internal Math.min()
                instructioncounter++; // for the external Math.min()

            } // end of for j

        } // end of for i


        out.println("in Example 7, for size n = " + n
                + ", counter is: " + instructioncounter
                + ", (counter/n) is:" + (instructioncounter / n));

    }  // end of countInstructions()


}  // end of class CalculateRunTimes
