// #### Lab 01 Task C start of a possible solution ####



import static java.lang.System.out;

public class TheRunTimes {


    public static void main(String args[]) {


        out.println(" Lab 02 ---------------------------------- ");

        // create an instance from the CalculateRunTimes class
        
        CalculateRunTimes runtimes = new CalculateRunTimes();
        
        runtimes.countInstructions(10);
// ...
        runtimes.countInstructions(100);
// ...
        runtimes.countInstructions(1000);

        runtimes.countInstructions(10000);

        runtimes.countInstructions(50000);

        //  etc.

        out.println(" Lab 02 ---------------------------------- ");


    }


}
