// #### Lab 03 start of a possible solution ####


package edu.indiana.cs.c343;


import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.net.*;
public class TweetCollection {
    //use a List for tweets
    private List<TweetClass> tweetList;
    //constructor
    public TweetCollection() throws IOException {
        //use LinkedList
        tweetList = new LinkedList<TweetClass>();
        getTweetUrl();
    }
    //get tweets from a URL
    public void getTweetUrl() throws IOException {
        //use Scanner to read data steam
        URL u = new URL("http://homes.sice.indiana.edu/classes/fall2020/csci/c343-mitja/test2020/tweet-data-September10.txt");
        Scanner in = new Scanner(u.openStream());
        while(in.hasNext()) {
            String line = in.nextLine();
            //use regular expression match to extract name of the writer & tweet content.
            //compile the pattern
            Pattern p = Pattern.compile("^(\\S+)\\s+(.*)");
            //do the match
            Matcher m = p.matcher(line);
            if(m.find()) {
                String writer = m.group(1);
                String tweet = m.group(2);
                //System.out.println("writer: " + writer + " message: " + tweet);
                TweetClass atwt = new TweetClass(writer, tweet);
                tweetList.add(atwt);
            }
        }
        in.close();
    }
    public TweetClass get(int index) {
        return tweetList.get(index);
    }
    //a method to display the information
    public void summary() {
        System.out.println("Total tweets: " + tweetList.size());
    }
    //main method
    public static void main(String[] argv) throws IOException {
        TweetCollection tc = new TweetCollection();
        tc.summary();
        TweetClass one = tc.get(0);
        one.display();
    }
}
