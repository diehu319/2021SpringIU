// #### Lab 05 selected solutions ####


// ------
// Task B
// ------

// ...

private void inorder(BinNode<K> entry) {
    if (entry==null)
        return;

    System.out.print("[ ");
    if (entry.getLeft() != null)
        inorder(entry.getLeft());
    System.out.print(entry.getKey() + "(" + entry.getSize() + ") ");
    if (entry.getRight() != null)
        inorder(entry.getRight());
    System.out.print("] ");
}

private void postorder(BinNode<K> entry) {
    if (entry==null)
        return;
    System.out.print("[ ");
    if (entry.getLeft() != null)
        postorder(entry.getLeft());
    if (entry.getRight() != null)
        postorder(entry.getRight());
    System.out.print(entry.getKey() + "(" + entry.getSize() + ") ");
    System.out.print("] ");
}

// ...
