// #### Lab 05 selected solutions ####


// ------
// Task A
// ------

// ...

    // "unbalanced" is used for balance checking:
    //    if a node is unbalanced, the tree will be unbalanced
    BinNode<K> unbalanced = null;

// ...


    // checkBalance() implementation:
    //
    public void checkBalance() {

        // we really use treeHeight() as a recursive helper function,
        //   as a side effect it'll set 
        int h = treeHeight(root);
        System.out.println("the height of the tree is " + h);
        
        if (this.unbalanced != null)
            System.out.println("the tree is UNBALANCED at node " + this.unbalanced.getKey());
        else System.out.println("the tree is balanced.");
    }

    // treeHeight() helper implementation:
    //
    public int treeHeight(BinNode<K> entry) {
        if (entry == null) {
            return 0;
        } else {
            int hLeft = treeHeight(entry.getLeft());
            int hRight = treeHeight(entry.getRight());
            System.out.println("checking key " + entry.getKey() + " :");
            System.out.println("    its left subtree height is " + hLeft + " and");
            System.out.println("    its right subtree height is " + hRight);
            if (Math.abs(hLeft - hRight) > 1) {
                this.unbalanced = entry;
                System.out.println("    it is therefore unbalanced!");
            } else {
                System.out.println("    we consider it balanced.");
            }            
            return Math.max(hLeft, hRight) + 1;
        }
    }

// ...

    public static void main(String[] argv) {
        BSTJr<Integer> tree = new BSTJr<Integer>();
        Integer[] ks1 = {37, 24, 42, 7, 2, 40, 120};
        tree.build(ks1);
        tree.display();
        tree.checkBalance();

        // another test:
        Integer[] ks2 = { 2, 7, 24, 37, 40, 42, 120};
        tree.root = null;
        tree.build(ks2);
        tree.display();
        tree.checkBalance();
    }

// ...
