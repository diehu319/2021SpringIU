public class TweetClass {
    private String content;
    private String author;

    // Class constructor
    public TweetClass(String content, String author) {
        this.content = content;
        this.author = author;
    }

    // A function that prints out the content of the tweet
    public String showTweet() {
        return ("\"" + content + "\"  ---- " + author);
    }

    // A function that tests whether the tweet contains a certain string s, true if matches, false otherwise
    public boolean contains(String s) {
        return (content.contains(s) ? true : false);
    }

    // A function that returns the author of a specific tweet
    public String getAuthor() {
        return author;
    }

    // A function that returns the content of a tweet
    public String getTweet() {
        return content;
    }
}
