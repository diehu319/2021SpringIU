import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TweetCollection {
    public ArrayList<String> getTweets(String content, ArrayList<TweetClass> tweet) {
        int counter = 0;
        ArrayList<String> matched= new ArrayList<String>();

        // Make it case insensitive
        Pattern pattern = Pattern.compile(content, Pattern.CASE_INSENSITIVE);

        for (int i = 0; i < tweet.size(); ++i) {
            String contentStr = tweet.get(i).getTweet();
            Matcher matcher = pattern.matcher(contentStr);
            if (matcher.find()) {
                // Add highlighter to the matching text
                contentStr = contentStr.substring(0, matcher.start()) + "[" + contentStr.substring(matcher.start(), matcher.end())+ "]" + contentStr.substring(matcher.end());
                matched.add(tweet.get(i).getAuthor() + " " + contentStr);
                counter++;
            }
        }

        System.out.println(counter + " matches found!");
        return matched;
    }

    public boolean tweetedAbout(String author, String content, ArrayList<TweetClass> tweet) {
        for (int i = 0; i < tweet.size(); ++i) {
            if (tweet.get(i).getAuthor().equals(author)) {
                if (tweet.get(i).getTweet().contains(content))
                    return true;
            }
        }

        return false;
    }

    public ArrayList<TweetClass> fetchAllTweets(String tweetsURL) {
        ArrayList<TweetClass> tweets = new ArrayList<TweetClass>();

        try {
            // Read from URL
            URL url = new URL(tweetsURL);
            Scanner readURL = new Scanner(url.openStream());

            System.out.println();
            while (readURL.hasNext()) {
                // Get the index of the first space " "
                String str = readURL.nextLine();
                int contentIndex = str.indexOf(" ");

                // Use the space index ton separate the author and the content, add them to the ArrayList
                tweets.add(new TweetClass(str.substring(contentIndex + 1), str.substring(0, contentIndex - 1)));
            }

        } catch (Throwable e) {
            System.out.println("An exception has occurred: " + e);
            e.printStackTrace();
        }

        return tweets;
    }

    public static void main(String[] args) {
        TweetCollection collect = new TweetCollection();
        ArrayList<TweetClass> tweets = new ArrayList<TweetClass>();
        tweets = collect.fetchAllTweets("http://homes.soic.indiana.edu/classes/fall2020/csci/c343-mitja/test2020/tweet-data-September10.txt");

        // Get tweets that contains all the specified string
        for (String line : collect.getTweets("big", tweets))
            System.out.println(line);
        System.out.println();
        for(String line: collect.getTweets("me", tweets))
            System.out.println(line);

        // Check if the specified author tweeted about the specified content
        ArrayList<String> authors = new ArrayList<String>();
        for (int i = 0; i < 10; ++i)
            authors.add(tweets.get(new Random().nextInt(tweets.size())).getAuthor());

        System.out.println("\nRandom chose author: " + authors);
        for (int i = 0; i < authors.size(); ++i) {
            if (collect.tweetedAbout(authors.get(i), "so", tweets ))
                System.out.println("Yes, " + authors.get(i) + " tweeted about \"data\"");
            else
                System.out.println("No, " + authors.get(i) + " didn't tweet about \"data\"");
        }
    }
}
