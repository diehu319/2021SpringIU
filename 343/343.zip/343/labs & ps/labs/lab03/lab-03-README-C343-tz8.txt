Inside the TweetCollection.java, I wrote a separate method called fetchAllTweets() for fetching all the tweets from the URL given to make things 
organized and clean.

For the tweetedAbout() method, I first check if the TweetClass ArrayList objects has the author that user specified, then I check if the author
wrote something about the content that user specified simply by using an if statement. If two conditions met, then return true, otherwise it will 
return false. I implemented it by choosing 10 random authors from the ArrayList<TweetClass> object first, then I put them in a for loop with the 
content that user specified to check if that author wrote something about it. If yes. print the "yes" messages about it, if no. print a "no" message.

For the getTweets() method, I used Java Matcher and Pattern to check if a tweet contains the user specified content. I implemented it by using
a simple if statement with matcher.find() as the condition.