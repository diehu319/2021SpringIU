public class BSTJr <K extends Comparable<?super K>> {
    BinNode<K> root;
    BinNode<K> curr;

    // TODO for C343/Fall 2020 - Lab 05 part A
    // "unbalanced" is used for balance checking:
    //    if a node is unbalanced, the tree will be unbalanced
    BinNode<K> unbalanced = null;

    int leftHeight = 0;
    int rightHeight = 0;

    public BSTJr() {
        root = null;
        curr = null;
    }

    public void build(K[] ks) {
        for (int i = 0; i < ks.length; i ++)
            insert(ks[i]);
    }

    public void insert(K k) {
        BinNode<K> t = new BinNode<K>(k);
        if (root == null) {
            root = curr = t;
        } else {
            curr = search(root, k);
            if (k.compareTo(curr.getKey()) < 0)
                curr.setLeft(t);
            else
                curr.setRight(t);
        }
    }

    public BinNode<K> search(BinNode<K> entry, K k) {
        if (entry == null)
            return null;
        else {
            entry.setSize(entry.getSize() + 1); //update the size of the subtree by one
            if (entry.isLeaf())
                return entry;
            if (k.compareTo(entry.getKey()) < 0) {
                if (entry.getLeft() != null)
                    return search(entry.getLeft(), k);
                else
                    return entry;
            } else {
                if (entry.getRight() != null)
                    return search(entry.getRight(), k);
                else
                    return entry;
            }
        }
    }

    public void display() {
        if (root == null) return;
        System.out.println("Preorder enumeration: key(size-of-the-subtree)");
        preorder(root);
        System.out.println();
    }

    public void display(int traversalMode) {
        switch (traversalMode){
            // Inorder traversal
            case 1:
                System.out.println("Inorder:");
                inorder(root);
                System.out.println();
                break;

            // Preorder traversal
            case 2:
                System.out.println("Preorder:");
                preorder(root);
                System.out.println();
                break;

            // Postorder traversal
            case 3:
                System.out.println("Postorder:");
                postorder(root);
                System.out.println();
                break;
        }
    }

    public void inorder(BinNode<K> entry) {
        if (entry == null) return;

        inorder(entry.getLeft());
        System.out.print(entry.getKey() + "(" + entry.getSize() + ") ");
        inorder(entry.getRight());
    }

    public void preorder(BinNode<K> entry) {
        if (entry == null) return;

        System.out.print(entry.getKey() + "(" + entry.getSize() + ") ");
        if (entry.getLeft() != null) preorder(entry.getLeft());
        if (entry.getRight() != null) preorder(entry.getRight());
    }

    public void postorder(BinNode<K> entry) {
        if (entry == null) return;

        postorder(entry.getLeft());
        postorder(entry.getRight());
        System.out.print(entry.getKey() + "(" + entry.getSize() + ") ");
    }

    public int findChildCount(BinNode<K> entry) {
        if(entry == null) return 0;
        return findChildCount(entry.getLeft()) + findChildCount(entry.getRight()) + 1;
    }

    public BinNode<K> findKthSmallest(BinNode<K> entry, int k) {
        if(entry == null)
            return null;

        int leftCount = findChildCount(entry.getLeft());

        if(k == leftCount + 1)
            return entry;
        else if(k <= leftCount)
            return findKthSmallest(entry.getLeft(), k);
        else
            return findKthSmallest(entry.getRight(), k - leftCount - 1);

    }

    // TODO for C343/Fall 2020 - Lab 05 part A
    // implement checkBalance(),
    // and you may write treeHeight(node) as helper function
    public boolean checkBalance(BinNode<K> entry) {
        // Empty BST is considered to be balanced by definition
        if(entry == null)
            return true;

        // If the height difference for any subtree is larger than 1, then the whole BST is not balanced
        if(Math.abs(leftTreeHeight(entry) - rightTreeHeight(entry)) > 1) {
            unbalanced = entry;
            return false;
        }

        // Continue search for other nodes
        else {
            if(entry.getLeft() != null) checkBalance(entry.getLeft());
            if(entry.getRight() != null) checkBalance(entry.getRight());
        }

        return true;
    }

    public int leftTreeHeight(BinNode<K> entry) {
        if(entry == null)
            return 0;

        if(entry.getLeft() != null) {
            leftHeight++;
            leftTreeHeight(entry.getLeft());
        }

        return leftHeight;
    }

    public int rightTreeHeight(BinNode<K> entry) {
        if(entry == null)
            return 0;

        if(entry.getRight() != null) {
            rightHeight++;
            rightTreeHeight(entry.getRight());
        }

        return rightHeight;
    }

    public static void main(String[] argv) {
        BSTJr<Integer> tree1 = new BSTJr<Integer>();
        Integer[] ks1 = {1, 3, 5, 7, 9, 2, 4, 6, 8, 10, 11};
        tree1.build(ks1);
        tree1.display(1);
        tree1.display(2);
        tree1.display(3);
        System.out.println("kth smallest (k = 5): " + tree1.findKthSmallest(tree1.root, 5).getKey());
        System.out.println(tree1.checkBalance(tree1.root) ? "Tree1 is balanced\n" : "Tree1 is not balanced\n");

        BSTJr<Integer> tree2 = new BSTJr<Integer>();
        Integer[] ks2 = {50, 17, 9, 14, 12, 23, 19, 76, 54, 72, 67};
        tree2.build(ks2);
        tree2.display(1);
        tree2.display(2);
        tree2.display(3);
        System.out.println("kth smallest (k = 2): " + tree2.findKthSmallest(tree2.root, 2).getKey());
        System.out.println(tree2.checkBalance(tree2.root) ? "Tree2 is balanced\n" : "Tree2 is not balanced\n");

        BSTJr<Integer> tree3 = new BSTJr<Integer>();
        Integer[] ks3 = {1, 2, 4, 5, 3};
        tree3.build(ks3);
        tree3.display(1);
        tree3.display(2);
        tree3.display(3);
        System.out.println("kth smallest (k = 3): " + tree3.findKthSmallest(tree3.root, 3).getKey());
        System.out.println(tree3.checkBalance(tree3.root) ? "Tree3 is balanced\n" : "Tree3 is not balanced\n");

        BSTJr<Integer> tree4 = new BSTJr<Integer>();
        Integer[] ks4 = {5, 2};
        tree4.build(ks4);
        tree4.display(1);
        tree4.display(2);
        tree4.display(3);
        System.out.println("kth smallest (k = 2): " + tree4.findKthSmallest(tree4.root, 2).getKey());
        System.out.println(tree4.checkBalance(tree4.root) ? "Tree4 is balanced\n" : "Tree4 is not balanced\n");

        BSTJr<Integer> tree5 = new BSTJr<Integer>();
        Integer[] ks5 = {5, 8};
        tree5.build(ks5);
        tree5.display(1);
        tree5.display(2);
        tree5.display(3);
        System.out.println("kth smallest (k = 1): " + tree5.findKthSmallest(tree5.root, 1).getKey());
        System.out.println(tree5.checkBalance(tree5.root) ? "Tree5 is balanced\n" : "Tree5 is not balanced\n");

        BSTJr<Integer> tree6 = new BSTJr<Integer>();
        Integer[] ks6 = {5};
        tree6.build(ks6);
        tree6.display(1);
        tree6.display(2);
        tree6.display(3);
        System.out.println("kth smallest (k = 1): " + tree6.findKthSmallest(tree6.root, 1).getKey());
        System.out.println(tree6.checkBalance(tree6.root) ? "Tree6 is balanced\n" : "Tree6 is not balanced\n");
    }
}