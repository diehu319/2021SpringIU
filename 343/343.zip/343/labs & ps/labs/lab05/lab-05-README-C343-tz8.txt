Begin from the root node and save the number of nodes for its left subtree as COUNT;

if root is null
   return null
   
if COUNT+1 is equal to k
   return root
else if COUNT is greater than or equals to k+1
   return findKthSmallest(root.getRight(), k-COUNT-1)
else COUNT is less than or equals to k+1
   return findKthSmallest(root.getLeft(), k)