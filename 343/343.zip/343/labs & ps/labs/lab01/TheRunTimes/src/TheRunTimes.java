public class TheRunTimes {
    public static void main(String[] args) {
        CalculateRunTimes runtimes = new CalculateRunTimes();

        runtimes.countInstructions(10);
        runtimes.countInstructions(100);
        runtimes.countInstructions(1000);
        runtimes.countInstructions(10000);
    }
}