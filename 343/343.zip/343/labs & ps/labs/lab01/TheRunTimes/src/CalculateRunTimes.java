public class CalculateRunTimes {
    public void countInstructions(int n) {
        // ===================== Example 2 =====================
        int sum2 = 0;
        int instructioncounter = 1;
        for (int i = 1; i <= n; i++, instructioncounter++)
            for (int j = 1; j <= n; j++, instructioncounter++) {
                sum2++;
                instructioncounter++;
            }

        System.out.println("\nExample 2: n = " + n + ", instructioncounter = " + instructioncounter + ", rate(instructioncounter / n) = " + instructioncounter / n);


        // ===================== Example 7 =====================
        int c = 0;
        int m = 100;
        int a[] = new int[m + 1];
        int b[] = new int[n + 1];
        int d[][] = new int[m + 1][n + 1];

        instructioncounter = 5;

        for(int i = 1; i <= m; i ++, instructioncounter ++)  {
            for(int j = 1; j <= n; j ++, instructioncounter ++) {
                if (a[i] == b[j]) {
                    c = 0;
                    instructioncounter ++;
                } else {
                    c = 1;
                    instructioncounter ++;
                }

                int min2 = Math.min(Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1), d[i - 1][j - 1] + c);
                d[i][j] = min2;

                instructioncounter += 3;
            }
        }

        System.out.println("Example 7: n = " + n + ", instructioncounter = " + instructioncounter + ", rate = " + instructioncounter / n);
    }
}