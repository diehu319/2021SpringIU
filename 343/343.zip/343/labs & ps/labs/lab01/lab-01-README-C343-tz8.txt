Example 2:

n = 10, instructioncounter = 211, rate(instructioncounter / n) = 21
n = 100, instructioncounter = 20101, rate(instructioncounter / n) = 201
n = 1000, instructioncounter = 2001001, rate(instructioncounter / n) = 2001
n = 10000, instructioncounter = 200010001, rate(instructioncounter / n) = 20001

Example 7:

n = 10, instructioncounter = 5105, rate = 510
n = 100, instructioncounter = 50105, rate = 501
n = 1000, instructioncounter = 500105, rate = 500
n = 10000, instructioncounter = 5000105, rate = 500