import java.io.*;
import java.util.Random;

public class EditDistance {
    public int editDistance(String str1, String str2) {
        long startTime = System.nanoTime();

        // +1 for leading zeros
        int m = str1.length() + 1;
        int n = str2.length() + 1;
        int[][] distanceTable = new int[m][n];

        // Initialize the array
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                distanceTable[i][j] = 0;
            }
        }

        // Initialize the column
        for (int i = 0; i < m; ++i) {
            distanceTable[i][0] = i;
        }

        // Initialize the row
        for (int j = 0; j < n; ++j) {
            distanceTable[0][j] = j;
        }

        // Fill the table
        int num = 0;
        for (int i = 1; i < m; ++i) {
            for (int j = 1; j < n; ++j) {
                if(str1.charAt(i - 1) == str2.charAt(j - 1))
                    distanceTable[i][j] = distanceTable[i - 1][j - 1];
                else
                    distanceTable[i][j] = 1 + Math.min(Math.min(distanceTable[i][j - 1], distanceTable[i - 1][j]), distanceTable[i - 1][j - 1]);
            }
        }

        long endTime = System.nanoTime();

        System.out.println("Time elapsed (Edit Distance): " + (endTime - startTime) / 1000.0f + " ms");

        return distanceTable[m - 1][n - 1];
    }

    public int hammingDistance(String str1, String str2) {
        long startTime = System.nanoTime();
        int counter = 0;

        if (str1.length() != str2.length()) {
            return -1;
        } else {
            for (int i = 0; i < str1.length(); i++) {
                if (str1.charAt(i) != str2.charAt(i))
                    counter++;
            }
        }

        long endTime = System.nanoTime();

        System.out.println("Time elapsed: (Hamming Distance)" + (endTime - startTime) / 1000.0f + " ms");

        return counter;
    }

    public String readFromFile(String fileName) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        StringBuffer sb = new StringBuffer();
        String nextLine;

        while(((nextLine = br.readLine()) != null)) {
            sb.append(nextLine);
        }

        return sb.toString().replace("\n", " ");
    }

    public static void main(String[] args) throws IOException {
        EditDistance d1 = new EditDistance();
        System.out.println("\nEdit Distance (\"Apple\", \"Pineapple\") = " + d1.editDistance("Apple", "Pineapple"));
        System.out.println("Edit Distance (\"jfoiuwhbugqoierg\", \"uoihefiuasdhkljfew\") = " + d1.editDistance("jfoiuwhbugqoierg", "uoihefiuasdhkljfew"));
        System.out.println("Edit Distance (\"Gum\", \"gun\") = " + d1.editDistance("Gum", "gun"));

        EditDistance d2 = new EditDistance();
        String str1 = d2.readFromFile("1.txt");
        String str2 = d2.readFromFile("2.txt");
        System.out.println("Edit Distance (\"1.txt\", \"2.txt\") = " + d1.editDistance(str1, str2));
        System.out.println("Hamming Distance (\"1.txt\", \"2.txt\") = " + d1.hammingDistance(str1, str2));

        EditDistance d3 = new EditDistance();
        char[] DNASequence = {'A', 'C', 'G', 'T'};
        Random rand = new Random();
        String DNA1;
        String DNA2;
        DNA1 = DNA2 = "";

        try {
            for (int i = 4; true; i *= 2) {
                for (int j = 0; j < i; ++j) {
                    DNA1 += DNASequence[rand.nextInt(4)];
                    DNA2 += DNASequence[rand.nextInt(4)];
                }
                System.out.println("\nDNA1: " + DNA1 + "\nDNA2: " + DNA2);
                System.out.println("Edit Distance: " + d3.editDistance(DNA1, DNA2));
                System.out.println("Hamming Distance: " + d3.hammingDistance(DNA1, DNA2) + "\n");
                DNA1 = "";
                DNA2 = "";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
