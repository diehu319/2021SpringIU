BinaryTree output:
true
false
false
true
false
false