import java.util.ArrayList;
class Node {
    int value;
    Node left;
    Node right;

    Node (int value) {
        this.value = value;
        left = right = null;
    }
}

public class BinaryTree {
    Node root;

    BinaryTree() {
        root = null;
    }

    public Node addNodes(Node current, int value) {
        if (current == null)
            return new Node(value);

        if (value < current.value)
            current.left = addNodes(current.left, value);
        else if (value > current.value)
            current.right = addNodes(current.right, value);
        else
            return current;

        return current;
    }

    public Node add(int value) {
        root = addNodes(root, value);
        return root;
    }

    public boolean find(Node current, int value) {
        if (current == null)
            return false;

        if(value == current.value)
            return true;

        return value < current.value ? find(current.left, value) : find(current.right, value);
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        Node root = tree.add(5);
        tree.add(7);
        tree.add(3);
        tree.add(9);
        tree.add(1);
        tree.add(2);
        tree.add(8);
        tree.add(4);
        tree.add(10);
        tree.add(6);

        System.out.println(tree.find(root, 4));
        System.out.println(tree.find(root, 45));
        System.out.println(tree.find(root, 0));
        System.out.println(tree.find(root, 2));
        System.out.println(tree.find(root, 12));
        System.out.println(tree.find(root, 20));
    }
}
