import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Int2DArray implements Int2DArrayADT {
    private ArrayList<ArrayList<Long>> arr = new ArrayList<>();
    private int row, col;


    // Class constructor
    public Int2DArray(int row, int col) {
        this.row = row;
        this.col = col;

        for (int i = 0; i < row; ++i) {
            arr.add(new ArrayList<>());
            for (int j = 0; j < col; ++j) {
                arr.get(i).add(j, ThreadLocalRandom.current().nextLong(Integer.MIN_VALUE, Integer.MAX_VALUE));
            }
        }
    }

    public ArrayList<Long> convertTo1D(ArrayList<ArrayList<Long>> arr2D) {
        ArrayList<Long> arr1D = new ArrayList<>();

        for (int i = 0; i < arr2D.size(); ++i) {
            for (int j = 0; j < arr2D.get(i).size(); ++j) {
                arr1D.add(arr2D.get(i).get(j));
            }
        }

        return arr1D;
    }

    public ArrayList<ArrayList<Long>> convertTo2D(ArrayList<Long> arr1D) {
        ArrayList<ArrayList<Long>> arr2D= new ArrayList<>();

        for (int i = 0; i < this.row; ++i) {
            for (int j = 0; j < this.col; ++j) {
                arr2D.get(i).add(arr1D.remove(0));
            }
        }

        return arr2D;
    }

    public void display2DArray() {
        for (int i = 0; i < arr.size(); ++i) {
            for (int j = 0; j < arr.get(i).size(); ++j) {
                System.out.print(arr.get(i).get(j) + " ");
            }
            System.out.println();
        }
    }

    public int[] getSize() {
        int[] size = new int[2];

        size[0] = this.row;
        size[1] = this.col;

        return size;
    }

    public void set(int row, int col, long val) {
        arr.get(row).set(col, val);
    }

    public long get(int row, int col) {
        return arr.get(row).get(col);
    }

    public void zeroArray() {
        arr.clear();
    }

    public ArrayList getRow(int rowIndex) {
        return arr.get(rowIndex);
    }

    public void setRow(int rowIndex, ArrayList<Long> arrRow) {
        arr.set(rowIndex, arrRow);
    }

    public ArrayList getColumn(int colIndex) {
        ArrayList<Long> col = new ArrayList<>();

        for (int i = 0; i < arr.size(); ++i) {
            col.add(arr.get(i).get(colIndex));
        }

        return col;
    }

    public void setColumn(int colIndex, ArrayList<Long> arrCol) {
        for (int i = 0; i < arr.size(); ++i) {
            arr.get(i).set(colIndex, arrCol.get(i));
        }
    }

}
