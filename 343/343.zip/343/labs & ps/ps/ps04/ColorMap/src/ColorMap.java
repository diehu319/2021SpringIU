import javax.swing.*;
import java.awt.*;

public class ColorMap {
    private int width;
    private int height;
    private Int2DArray colorMap;

    // ColorMap class constructor to initialize the size of the colormap
    public ColorMap(Int2DArray colorMap) {
        this.colorMap = colorMap;
        this.width = colorMap.getSize()[0];
        this.height = colorMap.getSize()[1];
    }

    // Draw the whole colormap
    public void displayColorMap() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("ColorMap");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.add(new MyPanel());
                frame.pack();
                frame.setSize(width, height);
                frame.setVisible(true);
                frame.setResizable(true);
            }
        });
    }

    class MyPanel extends JPanel {
        public Dimension getPreferredSize() {
            return new Dimension(width, height);
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            long pixel;
            int pixelWid = 2;
            int pixelHei = 2;
            int xPos = 0;
            int yPos = 0;

            for (int row = 0; row < width; ++row) {
                for (int col = 0; col < height; ++col) {
                    pixel = colorMap.get(row, col);

                    if(pixel >= Integer.MIN_VALUE && pixel <= 0) {
                        g.setColor(Color.BLACK);
                        g.fillRect(xPos, yPos, pixelWid, pixelHei);
                    } else if(pixel >= 1 && pixel <= 254) {
                        g.setColor(Color.GRAY);
                        g.fillRect(xPos, yPos, pixelWid, pixelHei);
                    } else {
                        g.setColor(Color.WHITE);
                        g.fillRect(xPos, yPos, pixelWid, pixelHei);
                    }
                    xPos += pixelWid;

                }
                xPos = 0;
                yPos += pixelHei;
            }
        }

    }

    // Main method that test the ColorMap
    public static void main(String[] args) {
        // Test colorMap1
        ColorMap colorMap1 = new ColorMap(new Int2DArray(300, 300));
        colorMap1.displayColorMap();

//        // Test colorMap2
//        ColorMap colorMap2 = new ColorMap(new Int2DArray(400, 400));
//        colorMap2.displayColorMap();
    }
}
