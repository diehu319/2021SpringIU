import java.util.ArrayList;

public interface Int2DArrayADT {
    // A function that converts the 2D Array to 1D Array
    public ArrayList<Long> convertTo1D(ArrayList<ArrayList<Long>> arr2D);

    // A function that converts 1D Array back to 2D Array
    public ArrayList<ArrayList<Long>> convertTo2D(ArrayList<Long> arr1D);

    // A function that displays the 2D Array
    public void display2DArray();

    // A function that sets the value at a given position
    public void set(int row, int col, long val);

    // A function that gets the value at a given position
    public long get(int row, int col);

    // A function that empty the 2D Array
    public void zeroArray();

    // A function that gets all the values from a specified row
    public ArrayList getRow(int rowIndex);

    // A function that sets all the values of a given row
    public void setRow(int rowIndex, ArrayList<Long> arrRow);

    // A function that gets all the values from a specified column
    public ArrayList getColumn(int colIndex);

    // A function that sets all the values of a given column
    public void setColumn(int colIndex, ArrayList<Long> arrCol);
}
