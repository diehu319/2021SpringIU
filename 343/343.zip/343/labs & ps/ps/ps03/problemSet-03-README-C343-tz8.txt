Task A, 1:
For the StaticArray class, the scenarios stays the same since it uses index to find the position of the element. Even the element we want
to delete is the last element from the Array, the performance won't change since the operation has a linear time copmplexity. O(1)

For the DynamicArray class, the best scenario is that the element we want to delete is at the very end of the array (O(1)), because for dynamic
array, after an element got removed, the position of every other element will shift from right to left (exchanging values), and the size
of the array will decrease. In this case, the "decreased array size" is accomplished by creating a new array and copy the all the elements
from the original array to the new one. Based on that, imagine if the element we deleted is at the very end, then we don't even have to 
change the position of other elements inside the original array, all we have to do left is to copy all the elements over to the new array.
The average / worst case is that the element we are trying to remove is at the very beginning of the array (O(n)), because then we will have to shift every
other elements' position and value inside the original array, then finally we can proceed to do the copy and paste job.

Task A, 3:
The first version of removeAt() is more efficient because it uses index to do the work which has a linear time complexity O(1). But there are
drawbacks, for example, the size of the array will be fixed whether NULL is there or not, even though NULL does not take up any memory, the
array is still there. It is difficult to work with because imagine of have a large data set and you're using static array operations (such as
adding / removing elements) to do all the work, then the data set will have a bunch of NULL in there but the size of the data set will still
remain the same, which is not smart and the data set will become to a mess eventually. Thus, it's not suitable as being the standard implementation
in a "mordern" language. Tho the first version is still good for small data set, small data set is light weight and doesn't take up too much
memory, which is more desirable than using the second version because for the second version, it still will have to create a new copy of the
original array which took almost 1x the memory which is completely unnecessary.

Task B, 1:
ArrayList<Integer> nums = new ArrayList<Integer>();
int numToDelete = 15;
nums.add(2);
nums.add(23);
nums.add(15);
nums.add(5);
nums.add(9);
for (int i = 0; i < nums.size(); ++i) {
    if(nums.get(i) == numToDelete)
        delete();
}

First we create an ArrayList with type Integer, add elements into the ArrayList, then we can implement a for loop to loop through
the whole list, inside the for loop, we need to check if the current element is equal to the element we want to delete, if it is, 
then we call the delete() function provided by the ListADTs, if it's not, then proceed to the next element.

Task B, 2:
Given n > (DE / (P + E))
a) Array size: 20 * 8 = 160 bytes
   Single node size = 9 + 4 = 12 bytes
   n * 12 <= 160 -> n <= 13
   When n <= 13, linked list is preferable

b) Array size: 2 * 30 = 60 bytes
   Single node size = 4 + 2 = 6 bytes
   n * 6 <= 60 -> n <= 10
   When n <= 10, linked list is preferable

c) Array size: 1 * 30 = 30 bytes
   Single node size = 1 + 4 = 5 bytes
   n * 5 <= 30 -> n <= 6
   When n <= 6, linked list is preferable

d) Array size: 32 * 40 = 1280 bytes
   Single node size = 32 + 4 = 36 bytes
   n * 36 <= 1280 -> n <= 35
   When n <= 35, linked list is preferable

Task C, 1:
n! > 3^n > 4n^2 > 20n > n^(2/3) > log2(n) > log3(n) > 2

Task C, 2:
c_1n = O(n) - for values c = 10c_1, 0 <= f(n) <= 10c_1
c_1n = Ω(n) - same reason as above

c_2 * n^3 + c_3 = O(n^3) - for c = 100, 0 <= 100n <= f(n)
c_2 * n^3 + c_3 = Ω(n^2)

c_4 * n * log_2(n) + c_5 * n = O(nlog(n))
c_4 * n * log_2(n) + c_5 * n = Ω(n)

c_6 * 2^n + c_7 * n^6 = O(n^6)
c_6 * 2^n + c_7 * n^6 = Ω(2^n)

Task C, 3:
sum = 0;                        O(1) for assignment
if (EVEN(n)) {                  EVEN -> O(1), if(EVEN(n) -> O(1)
    for (i=0; i<n; i++) {       O(n) -> for loop
        sum++;                  O(1) -> ++ statement
    }           
} else {                
    sum = sum + n;              O(1) -> += statement
}

Upper bound -> O(n) - depends on how large n is
Avg. bound -> Θ(n) - depends on how large n is
Lower bound -> O(1) - when n = 1
