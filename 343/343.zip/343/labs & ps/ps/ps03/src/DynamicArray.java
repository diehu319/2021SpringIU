import java.util.Arrays;

public class DynamicArray {
    // Create a "dynamic" array
    static Integer[] numbers = {5, 4, 3, 6, 2, 1, 7, 0, 2, 2, 3, 1};

    public Integer removeAt(int index) {
        // If the index does not exist, return null
        if (index >= numbers.length || index < 0) {
            System.out.println("Index does not exist!");
            return null;
        }

        System.out.println("Removed " + numbers[index] + " at index " + index);

        // Shifting the numbers inside the array by exchanging their values
        int num = numbers[index];
        numbers[index] = null;
        for (int i = index; (i + 1) < numbers.length; ++i) {
            Integer temp = numbers[i];
            numbers[i] = numbers[i + 1];
            numbers[i + 1] = temp;
        }

        // Create a new array with decreased size
        Integer[] newArr = new Integer[numbers.length - 1];
        for (int i = 0; i < numbers.length - 1; ++i)
            newArr[i] = numbers[i];

        // Print out the new array
        System.out.println("New dynamic array: " + Arrays.toString(newArr) + " (Size: " + newArr.length + ")");

        // Return the number that got removed from the original array
        return num;
    }

    public static void main(String[] args) {
        // Create a class object
        DynamicArray dynamicArr = new DynamicArray();
        int removeIndex = 7;

        System.out.println("\nOriginal dynamic array: " + Arrays.toString(numbers) + " (Size: " + numbers.length + ")");
        dynamicArr.removeAt(removeIndex);
    }
}
