import java.util.Arrays;

public class StaticArray {
    // Create a "static" array
    static Integer[] numbers = {4, 3, 5, 2, 6, 12, 9, 7, 5, 3};

    public Integer removeAt(int index) {
        Integer num = numbers[index];
        numbers[index] = null;

        return num;
    }

    public static void main(String[] args) {
        // Create a class object
        StaticArray staticArr = new StaticArray();
        int removeIndex = 6;

        System.out.println("\nOriginal static array: " + Arrays.toString(numbers));
        System.out.println("Removed " + staticArr.removeAt(removeIndex) + " at index " + removeIndex + ", replaced with null.");
        System.out.println("New static array: " + Arrays.toString(numbers));
    }
}
