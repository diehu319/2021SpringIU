Java version:

java.vm.version is 14.0.2+12-46
java.vm.vendor is Oracle Corporation
java.vm.name is Java HotSpot(TM) 64-Bit Server VM
java.vm.specification.version is 14
java.vm.specification.vendor is Oracle Corporation
java.vm.specification.name is Java Virtual Machine Specification
java.version is 14.0.2
java.vendor is Oracle Corporation

====================================================================

Student class output:

Name: Cisco
Department: CSCI

Name: Jack
Department: SPH

Name: Wang
Department: CSCI

Name: Jerry
Department: BUS

Name: John
Department: SPH

Process finished with exit code 0

====================================================================

Time complexity analysis:

1. 
a = b + c;      ->      O(1) - The addition operation takes constant time complexity
d = a + e;      ->      O(1) - The addition operation takes constant time complexity
Overall time complexity: O(1)

2. 
sum = 0;                        ->      O(1) - The assignment operation takes constant time complexity
for (i=0; i<3; i++)             ->      O(1) - This operation is limited to 3, so it takes constant time complexity
    for (j=0; j<n; j++)         ->      O(n) - This operation is depends on the value of n, so it takes O(n) time complexity
        sum++;                  ->      O(1) - The addition operation takes constant time complexity
Overall time complexity: O(n). Even though it is a nested loop, the outer loop is limited to 3, thus it won't affect the total time complexity,
it's the inner loop part that matters since the limit for the inner loop is totally depends on the value of n, thus it will have an overall time
complexity of O(n)

3.
sum=0;                          ->      O(1) - The assignment operation takes constant time complexity
for (i=0; i<n*n; i++)           ->      O(n^2) - Since n*n == n^2 and the loop limit is depends on the value of n^2
    sum++;                      ->      O(1) - The addition operation takes constant time complexity
Overall time complexity: O(n^2)

4.
for (i=0; i < n-1; i++)         ->      O(n-1) - The loop limit is depends on the value of n-1
    for (j=i+1; j < n; j++) {   ->      O(n^2) - Nested loop of n, thus it's n^2
        tmp = AA[i][j];         ->      O(1) - The assignment operation takes constant time complexity
        AA[i][j] = AA[j][i];    ->      O(1) - The assignment operation takes constant time complexity
        AA[j][i] = tmp;         ->      O(1) - The assignment operation takes constant time complexity
    }
Overall time complexity: O(n^2).

5. 
sum = 0;                        ->      O(1) - The assignment operation takes constant time complexity
for (i=1; i<=n; i++)            ->      O(n) - The loop limit is depends on the value of n
    for (j=1; j<=n; j*=2)       ->      O(n*log(n)) - The multiplication operation takes log(n) time complexity, but it has to run n times eventually
        sum++;                  ->      O(1) - The addition operation takes constant time complexity
Overall time complexity: O(n*log(n))

6.
sum = 0;                        ->      O(1) - The assignment operation takes constant time complexity
for (i=1; i<=n; i*=2)           ->      O(n*log(n)) - The multiplication operation takes log(n) time complexity, but it has to run n times eventually
    for (j=1; j<=n; j++)        ->      O(n) - The loop limit is depends on the value of n
        sum++;                  ->      O(1) - The addition operation takes constant time complexity
Overall time complexity: O(n*log(n))

7. Assume that array A contains n values, random() takes constant time, and sort() takes (n log n) steps:
for (i=0; i<n; i++) {                   ->      O(n) - The loop limit is depends on the value of n
    for (j=0; j<n; j++)                 ->      O(n^2) - Nested loop with value n for both outer and inner loop, thus it's O(n^2)
        A[j] = DSutil.random(n);        ->      O(1) - random(n) takes constant time, A[j] assignment takes constant time, trhus overall it takes constant time
    sort(A);                            ->      O(nlog(n)) - Sort takes O(n * log(n)) times to execute
}
Overall time complexity: O(n^2). Since this is the slowest part of the code which has a big impact to the whole code in terms of speed

8. Assume that array A contains a random permutation of the values from 0 to (n - 1) in this case:
sum = 0;                        ->      O(1) - The assignment operation takes constant time complexity
for (i=0; i<n; i++)             ->      O(n) - The loop limit is depends on the value of n
    for (j=0; A[j]!=i; j++)     ->      O(n^2) - Since the loop needs to access all the elements inside the array A, and the size of array A is depends on the 
                                        value of n, we have a nested loop where n is actual the limit for both the outer and inner part of the loop
        sum++;                  ->      O(1) - The addition operation takes constant time complexity
Overall time complexity: O(n). 0 ~ (n - 1) is the same as 1 ~ n, thus the time it will take to access the whole array will depends on the size of the array A. 
Thus the overall time complexity is O(n^2)
