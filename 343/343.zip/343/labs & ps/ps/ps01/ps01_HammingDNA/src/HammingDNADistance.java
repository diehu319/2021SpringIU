public class HammingDNADistance {

    // Class default constructor
    public HammingDNADistance() {
    }

    // A method that compares the Hamming distance with two given DNAs
    public int HammingDistance(String D1, String D2) {
        // A counter to calculate the hamming distance
        int counter = 0;

        // Assume the input DNA strings have the same length
        if (D1.length() != D2.length()) {
            return -1;
        } else {
            for (int i = 0; i < D1.length(); i++) {
                if (D1.charAt(i) != D2.charAt(i))
                    counter++;
            }
        }

        // Return the calculated hamming distance of the given DNA strings
        return counter;
    }

}
