import java.util.Random;
import static java.lang.System.out;

public class RandomChunkOfDNA {

    // generate a random DNA sequence of length n:
    public String nextDNA(int n) {
        String lDNA = "";
        Random lRandomizer = new Random();

        for (int i = 0; i < n; i++) {
            int j = lRandomizer.nextInt(4);
            if (j == 0) lDNA += "A";
            else if (j == 1) lDNA += "T";
            else if (j == 2) lDNA += "C";
            else if (j == 3) lDNA += "G";
        }
        return lDNA;
    }

    // some client code for testing:
    public static void main(String[] argv) {
        RandomChunkOfDNA rndDNAGenerator = new RandomChunkOfDNA();
        String dna1, dna2;

        for (int i = 10; i <= 1000; i = i * 10) {
            dna1 = rndDNAGenerator.nextDNA(i);
            dna2 = rndDNAGenerator.nextDNA(i);
            HammingDNADistance hammingDis = new HammingDNADistance();

            out.println("\nA DNA sequence " + i + " characters long: " + dna1);
            out.println("A DNA sequence " + i + " characters long: " + dna2);
            out.println("Hamming distance: " + hammingDis.HammingDistance(dna1, dna2));
        }
    }

} // end of class RandomChunkOfDNA