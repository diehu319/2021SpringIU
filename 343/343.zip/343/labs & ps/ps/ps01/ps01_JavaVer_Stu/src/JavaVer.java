public class JavaVer {
    public static void main(String[] args) {
        System.out.println("\njava.vm.version is " + System.getProperty("java.vm.version"));
        System.out.println("java.vm.vendor is " + System.getProperty("java.vm.vendor"));
        System.out.println("java.vm.name is " + System.getProperty("java.vm.name"));
        System.out.println("java.vm.specification.version is " + System.getProperty("java.vm.specification.version"));
        System.out.println("java.vm.specification.vendor is " + System.getProperty("java.vm.specification.vendor"));
        System.out.println("java.vm.specification.name is " + System.getProperty("java.vm.specification.name"));
        System.out.println("java.version is " +  System.getProperty("java.version"));
        System.out.println("java.vendor is " + System.getProperty("java.vendor"));
    }
}
