public class Student {
    // Class attributes
    private String name;
    private String department;

    // Student class constructor
    public Student(String name) {
        this.name = name;
    }

    // A function that sets the department information for a student
    public void setDepartment(String departName) {
        this.department = departName;
    }

    // A function to display student information
    public void display() {
        System.out.println("\nName: " + this.name);
        System.out.println("Department: " + this.department);
    }

    // Main function for executing
    public static void main(String[] args) {
        // Create two students
        Student stu1 = new Student("Cisco");
        Student stu2 = new Student("Jack");

        // Access student functions (set department)
        stu1.setDepartment("CSCI");
        stu2.setDepartment("SPH");

        // Display information of the students
        stu1.display();
        stu2.display();

        // Create an array of students
        String[] names = {"Wang", "Jerry", "John"};
        String[] departments = {"CSCI", "BUS", "SPH"};
        Student[] stuList = new Student[3];

        // Loop through to assign their name and departments
        for (int i = 0; i < stuList.length; ++i) {
            stuList[i] = new Student(names[i]);
            stuList[i].setDepartment(departments[i]);
        }

        // Loop through to display students' info
        for (int i = 0; i < stuList.length; ++i)
            stuList[i].display();


    }

}
