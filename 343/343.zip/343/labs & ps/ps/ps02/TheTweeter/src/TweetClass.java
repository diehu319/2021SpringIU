public class TweetClass {
    private String content;
    private String author;

    // Class constructor
    public TweetClass(String content, String author) {
        this.content = content;
        this.author = author;
    }

    // A function that prints out the content of the tweet
    public String showTweet() {
        return ("\"" + content + "\"  ---- " + author);
    }

    // A function that tests whether the tweet contains a certain string s, true if matches, false otherwise
    public boolean contains(String s) {
        return (content.contains(s) ? true : false);
    }

    // A function that returns the author of a specific tweet
    public String getAuthor() {
        return author;
    }

    // A function that returns the content of a tweet
    public String getTweet() {
        return content;
    }

    // Main function
    public static void main(String[] args) {
        // Create a instance variable for TweetClass
        TweetClass tweet1 = new TweetClass("Oh my god this is a freaking tweet!", "Cisco");

        // Show the tweet
        System.out.println("\nTweet preview:");
        System.out.println(tweet1.showTweet());

        // Test if the tweet contains some string
        System.out.println("\nCheck contains() function:");
        System.out.println("Tweet contains 'god?': " + tweet1.contains("god"));
        System.out.println("Tweet contains 'boi?': " + tweet1.contains("boi"));

        // Get the author and the content of the tweet
        System.out.println("\nCheck getAuthor() and getTweet() functions:");
        System.out.println("Tweet: " + tweet1.content);
        System.out.println("Author: " + tweet1.author);

    }
}
