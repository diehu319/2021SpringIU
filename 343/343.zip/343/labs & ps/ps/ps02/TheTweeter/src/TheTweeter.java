import java.util.ArrayList;

public class TheTweeter {
    // Use ArrayList to store tweets
    ArrayList<TweetClass> tweets = new ArrayList<TweetClass>();

    // A function to add a tweet
    public void add(TweetClass t) {
        tweets.add(t);
    }

    // A function to remove all the tweets that are written by the specified author
    public void remove(String author) {
        System.out.println("Removing \"" + author + "\"...");

        for (TweetClass tws : new ArrayList<>(tweets)) {
            if (author.equals(tws.getAuthor()))
                tweets.remove(tws);
        }
    }

    // A function to return one TweetClass object that are written by the specified author
    public TweetClass get(String author) {
        for (int i = 0; i < tweets.size(); ++i) {
            if (author.equals(tweets.get(i).getAuthor()))
                return tweets.get(i);
        }
        return null;
    }

    // A function that displays all the tweets
    public void displayTweets() {
        System.out.println("Available tweets:");
        for (int i = 0; i < tweets.size(); ++i) {
            System.out.println("Tweet " + (i + 1) + ": " + tweets.get(i).showTweet());
        }
    }

    public static void main(String[] args) {
        // Create class instance variable
        TheTweeter tweetList = new TheTweeter();
        TweetClass tweet1 = new TweetClass("Damn, daniel!", "Daniel");
        TweetClass tweet2 = new TweetClass("White vans is great, they are good looking shoes.", "Cisco");
        TweetClass tweet3 = new TweetClass("It's 2AM and I'm still thinking what to eat cuz im hungry af", "Mike");
        TweetClass tweet4 = new TweetClass("XBOX ONE X > PS5", "xbox_fanboys");
        TweetClass tweet5 = new TweetClass("COVID-19 cases is rising very fast in the US", "FOX NEWS");
        TweetClass tweet6 = new TweetClass("Wendy's > McDonald's", "Wendy's Kitchen");
        TweetClass tweet7 = new TweetClass("I love Microsoft", "Cisco");
        TweetClass tweet8 = new TweetClass("I love Bill Gates", "Cisco");
        TweetClass tweet9 = new TweetClass("I love C343", "Cisco");
        TweetClass tweet10 = new TweetClass("NAH NAH NAH I LOVE YOU", "KK");
        TweetClass tweet11 = new TweetClass("I love C241", "Cisco");

        // Add TweetClass objects to the TheTweeter object
        tweetList.add(tweet1);
        tweetList.add(tweet2);
        tweetList.add(tweet3);
        tweetList.add(tweet4);
        tweetList.add(tweet5);
        tweetList.add(tweet6);
        tweetList.add(tweet7);
        tweetList.add(tweet8);
        tweetList.add(tweet9);
        tweetList.add(tweet10);
        tweetList.add(tweet11);

        // Show tweets
        System.out.println();
        tweetList.displayTweets();

        // Remove tweets by author, then print the tweets to verify
        System.out.println();
        tweetList.remove("Cisco");
        tweetList.displayTweets();

        // Show the TweetClass object by author
        System.out.println("\nShow TweetClass:");
        System.out.println(tweetList.get("KK"));
        System.out.println(tweetList.get("MNV"));
    }
}
