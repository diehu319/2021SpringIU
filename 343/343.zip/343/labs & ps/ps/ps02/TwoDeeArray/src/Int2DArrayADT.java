import java.util.ArrayList;

public interface Int2DArrayADT {
    // A function that converts the 2D Array to 1D Array
    public ArrayList<Integer> convertTo1D(ArrayList<ArrayList<Integer>> arr2D);

    // A function that converts 1D Array back to 2D Array
    public ArrayList<ArrayList<Integer>> convertTo2D(ArrayList<Integer> arr1D);

    // A function that displays the 2D Array
    public void display2DArray();

    // A function that sets the value at a given position
    public void set(int row, int col, int val);

    // A function that gets the value at a given position
    public int get(int row, int col);

    // A function that empty the 2D Array
    public void zeroArray();

    // A function that gets all the values from a specified row
    public ArrayList getRow(int rowIndex);

    // A function that sets all the values of a given row
    public void setRow(int rowIndex, ArrayList<Integer> arrRow);

    // A function that gets all the values from a specified column
    public ArrayList getColumn(int colIndex);

    // A function that sets all the values of a given column
    public void setColumn(int colIndex, ArrayList<Integer> arrCol);
}
