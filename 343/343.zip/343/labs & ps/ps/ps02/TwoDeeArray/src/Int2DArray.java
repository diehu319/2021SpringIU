import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Int2DArray implements Int2DArrayADT {
    private ArrayList<ArrayList<Integer>> arr = new ArrayList<>();
    private int row, col;

    // Class constructor
    public Int2DArray(int row, int col) {
        this.row = row;
        this.col = col;

        for (int i = 0; i < row; ++i) {
            arr.add(new ArrayList<>());
            for (int j = 0; j < col; ++j) {
                arr.get(i).add(j, new Random().nextInt(8) + 1);
            }
        }
    }

    public ArrayList<Integer> convertTo1D(ArrayList<ArrayList<Integer>> arr2D) {
        ArrayList<Integer> arr1D = new ArrayList<>();

        for (int i = 0; i < arr2D.size(); ++i) {
            for (int j = 0; j < arr2D.get(i).size(); ++j) {
                arr1D.add(arr2D.get(i).get(j));
            }
        }

        return arr1D;
    }

    public ArrayList<ArrayList<Integer>> convertTo2D(ArrayList<Integer> arr1D) {
        ArrayList<ArrayList<Integer>> arr2D= new ArrayList<>();

        for (int i = 0; i < this.row; ++i) {
            for (int j = 0; j < this.col; ++j) {
                arr2D.get(i).add(arr1D.remove(0));
            }
        }

        return arr2D;
    }

    public void display2DArray() {
        for (int i = 0; i < arr.size(); ++i) {
            for (int j = 0; j < arr.get(i).size(); ++j) {
                System.out.print(arr.get(i).get(j) + " ");
            }
            System.out.println();
        }
    }

    public void set(int row, int col, int val) {
        arr.get(row).set(col, val);
    }

    public int get(int row, int col) {
        return arr.get(row).get(col);
    }

    public void zeroArray() {
        arr.clear();
    }

    public ArrayList getRow(int rowIndex) {
        return arr.get(rowIndex);
    }

    public void setRow(int rowIndex, ArrayList<Integer> arrRow) {
        arr.set(rowIndex, arrRow);
    }

    public ArrayList getColumn(int colIndex) {
        ArrayList<Integer> col = new ArrayList<>();

        for (int i = 0; i < arr.size(); ++i) {
            col.add(arr.get(i).get(colIndex));
        }

        return col;
    }

    public void setColumn(int colIndex, ArrayList<Integer> arrCol) {
        for (int i = 0; i < arr.size(); ++i) {
            arr.get(i).set(colIndex, arrCol.get(i));
        }
    }

    public static void main(String[] args) {
        // Create 3 2D Arrays
        Int2DArray arr1 = new Int2DArray(4, 4);
        Int2DArray arr2 = new Int2DArray(4, 3);

        System.out.println("\n===================== arr1 test =====================\n");
        System.out.println("Display arr1 2D Array:");
        arr1.display2DArray();

        System.out.println("\nSet function test: (2, 2) -> 8; (1, 2) -> 9");
        arr1.set(2, 2, 8);
        arr1.set(1, 2, 9);
        arr1.display2DArray();

        System.out.println("\nGet function test:\n(3, 3) = " + arr1.get(3, 3));
        System.out.println("(2, 3) = " + arr1.get(2, 3));
        System.out.println("(1, 2) = " + arr1.get(1, 2));

        System.out.println("\ngetRow function test:");
        System.out.println("(row 2) = " + arr1.getRow(2));
        System.out.println("(row 1) = " + arr1.getRow(1));

        System.out.println("\nsetRow function test:\n(row 2) -> (4, 2, 5, 3)\n(row 1) -> (6, 4, 1, 8)");
        arr1.setRow(2, new ArrayList<Integer>(Arrays.asList(4, 2, 5, 3)));
        arr1.setRow(1, new ArrayList<Integer>(Arrays.asList(6, 4, 1, 8)));
        arr1.display2DArray();

        System.out.println("\ngetColumn function test:");
        System.out.println("(column 2) = " + arr1.getColumn(2));
        System.out.println("(column 1) = " + arr1.getColumn(1));

        System.out.println("\nsetColumn function test:\n(column 2) -> (1, 2, 7, 3)\n(column 1) -> (6, 5, 2, 9)");
        arr1.setColumn(2, new ArrayList<Integer>(Arrays.asList(1, 2, 7, 3)));
        arr1.setColumn(1, new ArrayList<Integer>(Arrays.asList(6, 5, 2, 9)));
        arr1.display2DArray();

        System.out.println("\nzeroArray function test:");
        arr1.zeroArray();
        System.out.println("2D Array now should not display anything: \n");
        arr1.display2DArray();



        System.out.println("===================== arr2 test =====================");
        System.out.println("Display arr2 2D Array:");
        arr2.display2DArray();

        System.out.println("\nSet function test: (2, 2) -> 8; (1, 2) -> 9");
        arr2.set(2, 2, 8);
        arr2.set(1, 2, 9);
        arr2.display2DArray();

        System.out.println("\nGet function test:\n(3, 1) = " + arr2.get(3, 1));
        System.out.println("(2, 1) = " + arr2.get(2, 1));
        System.out.println("(1, 1) = " + arr2.get(1, 1));

        System.out.println("\ngetRow function test:");
        System.out.println("(row 2) = " + arr2.getRow(2));
        System.out.println("(row 1) = " + arr2.getRow(1));

        System.out.println("\nsetRow function test:\n(row 2) -> (4, 5, 3)\n(row 1) -> (6, 1, 8)");
        arr2.setRow(2, new ArrayList<Integer>(Arrays.asList(4, 5, 3)));
        arr2.setRow(1, new ArrayList<Integer>(Arrays.asList(6, 1, 8)));
        arr2.display2DArray();

        System.out.println("\ngetColumn function test:");
        System.out.println("(column 2) = " + arr2.getColumn(2));
        System.out.println("(column 1) = " + arr2.getColumn(1));

        System.out.println("\nsetColumn function test:\n(column 2) -> (1, 3, 2, 4)\n(column 1) -> (6, 1, 1, 2)");
        arr2.setColumn(2, new ArrayList<Integer>(Arrays.asList(1, 3, 2, 4)));
        arr2.setColumn(1, new ArrayList<Integer>(Arrays.asList(6, 1, 1, 2)));
        arr2.display2DArray();

        System.out.println("\nzeroArray function test:");
        arr2.zeroArray();
        System.out.println("2D Array now should not display anything: \n");
        arr2.display2DArray();
    }

}
