import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MyDeckOfCards implements DeckADT {
    // Create an ArrayList of ArrayLists for categorizes
    ArrayList<String> cards = new ArrayList<String>();

    // A function to create a full set of cards
    public void initialize() {

        // Loop through to add cards for each category
        for (int i = 0; i < 4; ++i) {
            String s = (i == 0) ? "C" : (i == 1) ? "D" : (i == 2) ? "H" : "S";
            cards.add("A" + s);

            for (int j = 2 ; j <= 10; ++j) {
                cards.add(Integer.toString(j) + s);
            }

            cards.add("J" + s);
            cards.add("Q" + s);
            cards.add("K" + s);
        }
    }

    // A function to draw a random card from the deck and remove it
    public String drawRandomCard() {
        return (cards.remove(new Random().nextInt(cards.size())));
    }

    // A function to draw the top card of the deck
    public String drawTopCardFromDeck() {
        return cards.remove(0);
    }

    // A function to shuffle the deck
    public void shuffleDeck() {
        Collections.shuffle(cards);
        System.out.println("Shuffled!");
    }

    // A function to display the current deck stats
    public void displayDeck() {
        // Print out cards
        System.out.println("\nMy Cards: [" + cards.size() + " card(s)]\n" + cards + "\n");
    }

    public static void main(String[] args) {
        /* =============================== cards1 test ===============================*/
        System.out.println("\n================================== cards 1 test ==================================");

        // Create a class instance variable
        MyDeckOfCards cards1 = new MyDeckOfCards();

        // Create the first card set and print
        cards1.initialize();
        cards1.displayDeck();

        // Draw a random card 10 times and remove them from the deck
        System.out.println("Random draw started...");
        for (int i = 0; i < 10; ++i)
            System.out.println((i + 1) + " random draw: " + cards1.drawRandomCard());
        System.out.println("Random draw ended...");

        // Print the deck again to verify if the card got removed from the deck
        cards1.displayDeck();

        // Shuffle the deck and display the deck
        cards1.shuffleDeck();
        cards1.displayDeck();

        // Draw the first card from the deck then display the deck
        System.out.println("Drew the top card: " + cards1.drawTopCardFromDeck());
        cards1.displayDeck();

        // End msg
        System.out.println("=============================== cards 1 test ended ===============================\n");


        /* =============================== cards2 test ===============================*/
        System.out.println("\n\n\n================================== cards 2 test ==================================");
        // Create a class instance variable
        MyDeckOfCards cards2 = new MyDeckOfCards();

        // Create the first card set and print
        cards2.initialize();
        cards2.displayDeck();

        // Draw a random card 20 times and remove them from the deck
        System.out.println("Random draw started...");
        for (int i = 0; i < 20; ++i)
            System.out.println((i + 1) + " random draw: " + cards2.drawRandomCard());
        System.out.println("Random draw ended...");

        // Print the deck again to verify if the card got removed from the deck
        cards2.displayDeck();

        // Shuffle the deck several times and display the deck
        cards2.shuffleDeck();
        cards2.shuffleDeck();
        cards2.shuffleDeck();
        cards2.shuffleDeck();
        cards2.displayDeck();

        // Draw the first card from the deck then display the deck
        System.out.println("Drew the top card: " + cards2.drawTopCardFromDeck());
        cards2.displayDeck();
        System.out.println("Drew the top card: " + cards2.drawTopCardFromDeck());
        cards2.displayDeck();
        System.out.println("Drew the top card: " + cards2.drawTopCardFromDeck());
        cards2.displayDeck();

        // End msg
        System.out.println("=============================== cards 2 test ended ===============================\n");

    }

}
