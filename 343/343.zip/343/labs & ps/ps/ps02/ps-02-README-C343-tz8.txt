Task A:
================================== cards 1 test ==================================

My Cards: [52 card(s)]
[AC, 2C, 3C, 4C, 5C, 6C, 7C, 8C, 9C, 10C, JC, QC, KC, AD, 2D, 3D, 4D, 5D, 6D, 7D, 8D, 9D, 10D, JD, QD, KD, AH, 2H, 3H, 4H, 5H, 6H, 7H, 8H, 9H, 10H, JH, QH, KH, AS, 2S, 3S, 4S, 5S, 6S, 7S, 8S, 9S, 10S, JS, QS, KS]

Random draw started...
1 random draw: 8H
2 random draw: 5S
3 random draw: KD
4 random draw: 9H
5 random draw: JC
6 random draw: 9S
7 random draw: 5D
8 random draw: 3S
9 random draw: 4C
10 random draw: 8D
Random draw ended...

My Cards: [42 card(s)]
[AC, 2C, 3C, 5C, 6C, 7C, 8C, 9C, 10C, QC, KC, AD, 2D, 3D, 4D, 6D, 7D, 9D, 10D, JD, QD, AH, 2H, 3H, 4H, 5H, 6H, 7H, 10H, JH, QH, KH, AS, 2S, 4S, 6S, 7S, 8S, 10S, JS, QS, KS]

Shuffled!

My Cards: [42 card(s)]
[AC, 10D, 10S, QC, 3C, 7H, QD, 6D, 6H, 7S, 4S, AD, 6S, AS, 4D, 4H, 10C, 8C, 2C, 2S, KH, 9C, JD, QS, 3H, 10H, QH, 7C, 2D, JS, 9D, KS, 8S, 3D, KC, 2H, 7D, 5C, 5H, JH, 6C, AH]

Drew the top card: AC

My Cards: [41 card(s)]
[10D, 10S, QC, 3C, 7H, QD, 6D, 6H, 7S, 4S, AD, 6S, AS, 4D, 4H, 10C, 8C, 2C, 2S, KH, 9C, JD, QS, 3H, 10H, QH, 7C, 2D, JS, 9D, KS, 8S, 3D, KC, 2H, 7D, 5C, 5H, JH, 6C, AH]

=============================== cards 1 test ended ===============================




================================== cards 2 test ==================================

My Cards: [52 card(s)]
[AC, 2C, 3C, 4C, 5C, 6C, 7C, 8C, 9C, 10C, JC, QC, KC, AD, 2D, 3D, 4D, 5D, 6D, 7D, 8D, 9D, 10D, JD, QD, KD, AH, 2H, 3H, 4H, 5H, 6H, 7H, 8H, 9H, 10H, JH, QH, KH, AS, 2S, 3S, 4S, 5S, 6S, 7S, 8S, 9S, 10S, JS, QS, KS]

Random draw started...
1 random draw: 8H
2 random draw: JD
3 random draw: 2D
4 random draw: 7S
5 random draw: 6S
6 random draw: 5D
7 random draw: 7D
8 random draw: AC
9 random draw: AH
10 random draw: QH
11 random draw: 2C
12 random draw: JS
13 random draw: 8C
14 random draw: 7H
15 random draw: 4C
16 random draw: 5H
17 random draw: 9H
18 random draw: KH
19 random draw: 9D
20 random draw: 9C
Random draw ended...

My Cards: [32 card(s)]
[3C, 5C, 6C, 7C, 10C, JC, QC, KC, AD, 3D, 4D, 6D, 8D, 10D, QD, KD, 2H, 3H, 4H, 6H, 10H, JH, AS, 2S, 3S, 4S, 5S, 8S, 9S, 10S, QS, KS]

Shuffled!
Shuffled!
Shuffled!
Shuffled!

My Cards: [32 card(s)]
[4S, 10S, 4D, 6C, 2H, 7C, 2S, 10H, 6D, 8D, AS, 10C, 3C, 8S, 4H, 5C, 9S, QD, 3D, KS, KD, KC, JC, QC, 5S, AD, 10D, 6H, 3S, QS, JH, 3H]

Drew the top card: 4S

My Cards: [31 card(s)]
[10S, 4D, 6C, 2H, 7C, 2S, 10H, 6D, 8D, AS, 10C, 3C, 8S, 4H, 5C, 9S, QD, 3D, KS, KD, KC, JC, QC, 5S, AD, 10D, 6H, 3S, QS, JH, 3H]

Drew the top card: 10S

My Cards: [30 card(s)]
[4D, 6C, 2H, 7C, 2S, 10H, 6D, 8D, AS, 10C, 3C, 8S, 4H, 5C, 9S, QD, 3D, KS, KD, KC, JC, QC, 5S, AD, 10D, 6H, 3S, QS, JH, 3H]

Drew the top card: 4D

My Cards: [29 card(s)]
[6C, 2H, 7C, 2S, 10H, 6D, 8D, AS, 10C, 3C, 8S, 4H, 5C, 9S, QD, 3D, KS, KD, KC, JC, QC, 5S, AD, 10D, 6H, 3S, QS, JH, 3H]

=============================== cards 2 test ended ===============================

Task B:

TweetClass.java output:
Tweet preview:
"Oh my god this is a freaking tweet!"  ---- Cisco

Check contains() function:
Tweet contains 'god?': true
Tweet contains 'boi?': false

Check getAuthor() and getTweet() functions:
Tweet: Oh my god this is a freaking tweet!
Author: Cisco

TheTweeter.java output:
Available tweets:
Tweet 1: "Damn, daniel!"  ---- Daniel
Tweet 2: "White vans is great, they are good looking shoes."  ---- Cisco
Tweet 3: "It's 2AM and I'm still thinking what to eat cuz im hungry af"  ---- Mike
Tweet 4: "XBOX ONE X > PS5"  ---- xbox_fanboys
Tweet 5: "COVID-19 cases is rising very fast in the US"  ---- FOX NEWS
Tweet 6: "Wendy's > McDonald's"  ---- Wendy's Kitchen
Tweet 7: "I love Microsoft"  ---- Cisco
Tweet 8: "I love Bill Gates"  ---- Cisco
Tweet 9: "I love C343"  ---- Cisco
Tweet 10: "NAH NAH NAH I LOVE YOU"  ---- KK
Tweet 11: "I love C241"  ---- Cisco

Removing "Cisco"...
Available tweets:
Tweet 1: "Damn, daniel!"  ---- Daniel
Tweet 2: "It's 2AM and I'm still thinking what to eat cuz im hungry af"  ---- Mike
Tweet 3: "XBOX ONE X > PS5"  ---- xbox_fanboys
Tweet 4: "COVID-19 cases is rising very fast in the US"  ---- FOX NEWS
Tweet 5: "Wendy's > McDonald's"  ---- Wendy's Kitchen
Tweet 6: "NAH NAH NAH I LOVE YOU"  ---- KK

Show TweetClass:
TweetClass@70177ecd
null

Task C:
1. 2D array has two essential concepts: row and column. The operations that can be used on a 2D array are very similar to those on 1D array.

Print: 2D array can be printed using for loop or a while loop, or other methods, simply control the row and the column variables and we should be good.

Empty check: Similar to 1D array, to check if a 2D array is empty, simply check the size of it. If the size is 0, then the array is def. empty.

Insertion: For 2D array, insertion is a bit different. say we have a 3*3 board right here:
     0 1 2                                                                0 1 2

0    1 3 4                                                           0    1 3 4
1    5 2 6      now we want to insert a 3 right between 5 and 2 ->   1    5 3 2     -> 2 is originally at arr[1][1], this is the position we want to insert
2    7 9 8                                                           2    6 7 9
                                                                     3    8
For ArrayList, insertion of a 2D array can be achieved using the insert() function, but we also need to think about the position of other elements after the
insertion process, that can be a little bit complicated if we really think about it. So, in order to accomplish the insertion operation with ease, we can first transform a 2D array into a 1D array.
We can then create another ArrayList, loop through all the elements inside the 2D array and put them into the newly-created 1D array. then we use the insert() function right
there. After the insertion, we then use 2 for-loops to transform the 1D array back to 2D array.

To create a 2D array using ArrayList:
ArrayList<ArrayList<Integer>> arr1 = new ArrayList<>(); which stands for an ArrayList of an ArrayList, which makes it a 2D array
To initialize it with rows and columns, we can break this into 2 parts: Inner and outer:

Inner stands for column: ArrayList<Integer> col = new ArrayList<>(Arrays.asList(1, 2, 3));
Outer stands for row, but we don't need to initialize that explicitly because the the number of rows is depending on the size of the inner array, that is,
if there are 5 elements for the inner ArrayList, then there will be 5 rows. (the size() function).

Delete: In order to delete a row or a column, we need to specify which row or column we're going to delete. Let's say we want to delete the second row of a 4*4 2D array,
ArrayList<ArrayList<Integer>> arr1 = new ArrayList<>();
Now the inner part is ArrayList<Integer>, the outer part is ArrayList<inner_part>(), each element inside the outer part is a row.
So we can delete a row by simply using arr1.get(0).remove(index) to remove a whole row.
In order to delete a column, we first need to imagine how does a column look like in an ArrayList. We can think the column as the first element of each inner element of
the outer part. So in order to delete a column, say column 2, we can use a for-loop:

for (int i = 0; i < arr1.size(); ++i) {
    arr1.get(i).remove(index);
}

We can also delete a single element inside a 2D array, but that will prob make the 2D array unbalanced. 

Size: To get the size of a 2D array, there're some circumstances:
    1. Assume the 2D array is in a fixed size and it is balanced: All we need to do is to multiply the size of the outer part to the size of the inner part
    2. Assume the 2D array is not in a fixed size: We need to set a counter, loop through all the elements and do some addition operation. 


TwoDeeArray output:

===================== arr1 test =====================

Display arr1 2D Array:
6 1 7 4 
3 1 1 1 
2 7 7 7 
1 5 6 3 

Set function test: (2, 2) -> 8; (1, 2) -> 9
6 1 7 4 
3 1 9 1 
2 7 8 7 
1 5 6 3 

Get function test:
(3, 3) = 3
(2, 3) = 7
(1, 2) = 9

getRow function test:
(row 2) = [2, 7, 8, 7]
(row 1) = [3, 1, 9, 1]

setRow function test:
(row 2) -> (4, 2, 5, 3)
(row 1) -> (6, 4, 1, 8)
6 1 7 4 
6 4 1 8 
4 2 5 3 
1 5 6 3 

getColumn function test:
(column 2) = [7, 1, 5, 6]
(column 1) = [1, 4, 2, 5]

setColumn function test:
(column 2) -> (1, 2, 7, 3)
(column 1) -> (6, 5, 2, 9)
6 6 1 4 
6 5 2 8 
4 2 7 3 
1 9 3 3 

zeroArray function test:
2D Array now should not display anything: 

===================== arr2 test =====================
Display arr2 2D Array:
7 3 3 
1 3 8 
2 3 8 
6 6 3 

Set function test: (2, 2) -> 8; (1, 2) -> 9
7 3 3 
1 3 9 
2 3 8 
6 6 3 

Get function test:
(3, 1) = 6
(2, 1) = 3
(1, 1) = 3

getRow function test:
(row 2) = [2, 3, 8]
(row 1) = [1, 3, 9]

setRow function test:
(row 2) -> (4, 5, 3)
(row 1) -> (6, 1, 8)
7 3 3 
6 1 8 
4 5 3 
6 6 3 

getColumn function test:
(column 2) = [3, 8, 3, 3]
(column 1) = [3, 1, 5, 6]

setColumn function test:
(column 2) -> (1, 3, 2, 4)
(column 1) -> (6, 1, 1, 2)
7 6 1 
6 1 3 
4 1 2 
6 2 4 

zeroArray function test:
2D Array now should not display anything: 


