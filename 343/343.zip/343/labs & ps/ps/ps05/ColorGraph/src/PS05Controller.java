import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class PS05Controller implements Observer {
    private static int width;
    private static int height;

    PS05View view;
    JFrame frame;

    @Override
    public void update(Observable o, Object arg) {
        // Get the current 2D ArrayList
        ArrayList<ArrayList<Integer>> colorArr;
        colorArr = ((PS05Model) o).getArray();

        // Update the color graph
        view = new PS05View(width, height);
        frame = new JFrame("Color Graph");
        frame.add(view);
        frame.setSize(width, height);
        frame.setVisible(true);
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Draw pixels
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                view.drawPoint(j, i, colorArr.get(i).get(j));
            }
        }

        view.clear();
    }

    public static void main(String[] args) {
        // Get screen resolution and pass it to PS05Model and PS05View
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//        width = (int) screenSize.getWidth();
//        height= (int) screenSize.getHeight();
        width = 500;
        height = 300;

        System.out.println("\nScreen resolution: " + width + "*" + height + "\n");

        // Setup Observable and Observer and hook them up
        PS05Model modelObservable = new PS05Model(width, height);
        PS05Controller controllerObserver = new PS05Controller();
        modelObservable.addObserver(controllerObserver);

        // Test Observer
        modelObservable.sortArray1(modelObservable.getArray());
        modelObservable.sortArray2(modelObservable.getArray());
    }
}
