import javax.swing.*;
import java.awt.*;

public class PS05View extends JComponent {
    private final int width;
    private final int height;
    private int x, y;

    Graphics g;

    // Class constructor
    PS05View(int width, int height) {
        this.width = width;
        this.height = height;
    }

    // A method that can draw a point on a View, one at a time
    public void drawPoint(int x, int y, int value) {
        g = getGraphics();

        if (value == -255) {
            g.setColor(new Color(255, 0, 0));
            g.drawLine(x, y, x, y);
        } else if (value >= -254 && value <= -1) {
            g.setColor(new Color(Math.abs(value), 0, 0));
            g.drawLine(x, y, x, y);
        } else if (value == 0) {
            g.setColor(new Color(0, 0, 0));
            g.drawLine(x, y, x, y);
        } else if (value >= 1 && value <= 255) {
            g.setColor(new Color(0, value, 0));
            g.drawLine(x, y, x, y);
        } else {
            g.setColor(new Color(0, 255, 0));
            g.drawLine(x, y, x, y);
        }
    }

    // A method that can clear the entire content of the View (to black)
    public void clear() {
        g = this.getGraphics();

        g.setColor(new Color(0, 0, 0));
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                drawPoint(j, i, 0);
            }
        }

        g.drawLine(x, y, x, y);
    }
}