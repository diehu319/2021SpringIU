import java.awt.*;
import java.util.ArrayList;
import java.util.Observable;
import java.util.concurrent.ThreadLocalRandom;

public class PS05Model extends Observable {
    private final int width;
    private final int height;
    ArrayList<ArrayList<Integer>> modelArray;

    // Class constructor
    PS05Model(int width, int height) {
        this.width = width;
        this.height = height;
        modelArray = new ArrayList<>();
        randomize(modelArray);
    }

    // A method that returns the reference of the 3D ArrayList
    public ArrayList<ArrayList<Integer>> getArray() {
        return modelArray;
    }

    // A method that randomizes all the elements inside the ArrayList with values between -255 to +255
    public void randomize(ArrayList<ArrayList<Integer>> modelArray) {
        for (int row = 0; row < height; ++row) {
            modelArray.add(new ArrayList<Integer>());
            for (int col = 0; col < width; ++col) {
                modelArray.get(row).add(col, ThreadLocalRandom.current().nextInt(-255, 255 + 1));
            }
        }
    }

    // A method that sorts each column inside the ArrayList in ascending order
    public void sortColumns(ArrayList<ArrayList<Integer>> modelArray) {
        ArrayList<Integer> colArray = new ArrayList<>();

        int colIndex = 0;
        for (int i = 0; i < width; ++i) {
            for (int j = 0; j < height; ++j) {
                colArray.add(modelArray.get(j).get(i));
            }

            // Sort the column with Bubble Sort
            BubbleSort bubbleSort = new BubbleSort();
            bubbleSort.sort(colArray, colArray.size());

            // Assign sorted column to the original ArrayList
            for (int x = 0; x < height; ++x)
                modelArray.get(x).set(colIndex, colArray.get(x));
            colIndex++;

            colArray.clear();
        }

        setChanged();
        notifyObservers();
    }

    // A method that sorts each row inside the ArrayList in ascending order
    public void sortRows(ArrayList<ArrayList<Integer>> modelArray) {
        ArrayList<Integer> rowArray = new ArrayList<>();

        int rowIndex = 0;
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                rowArray.add(modelArray.get(i).get(j));
            }

            // Sort the column with Bubble Sort
            BubbleSort bubbleSort = new BubbleSort();
            bubbleSort.sort(rowArray, rowArray.size());

            // Assign sorted row to the original ArrayList
            for (int x = 0; x < width; ++x)
                modelArray.get(rowIndex).set(x, rowArray.get(x));
            rowIndex++;

            rowArray.clear();
        }

        setChanged();
        notifyObservers();
    }

    // A method that sort each column inside the 2D ArrayList first, then the rows
    public void sortArray1(ArrayList<ArrayList<Integer>> modelArray) {
        sortColumns(modelArray);
        sortRows(modelArray);
    }

    // A method that sort each row inside the 2D ArrayList first, then the columns
    public void sortArray2(ArrayList<ArrayList<Integer>> modelArray) {
        sortRows(modelArray);
        sortColumns(modelArray);
    }

    public ArrayList<Integer> getRow(int rowIndex) {
        ArrayList<Integer> row = new ArrayList<>();

        for (int i = 0; i < width; ++i)
            row.add(modelArray.get(rowIndex).get(i));

        return row;
    }

    public ArrayList<Integer> getCol(int colIndex) {
        ArrayList<Integer> col = new ArrayList<>();

        for (int i = 0; i < height; ++i)
            col.add(modelArray.get(i).get(colIndex));

        return col;
    }

    // A Bubble Sort inner class
    static class BubbleSort {
        public void sort(ArrayList<Integer> arr, int length) {
            int i, j, temp;
            boolean swapped;

            for (i = 0; i < length - 1; ++i) {
                swapped = false;

                for (j = 0; j < length - i - 1; ++j) {
                    if (arr.get(j) > arr.get(j + 1)) {
                        temp = arr.get(j);
                        arr.set(j, arr.get(j + 1));
                        arr.set(j + 1, temp);
                        swapped = true;
                    }
                }

                if (!swapped)
                    break;
            }
        }
    }
}
