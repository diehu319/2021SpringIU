sortArray1()
not guaranteed to be "fully sorted"
because the order of the array

sortArray2()
not guaranteed to be "fully sorted"
because the order of the array

Time complexity:
sortArray1(): O(n^2)
sortArray2(): O(n^2)

Running time:
sortArray1(): 0.276s
sortArray2(): 0.096s